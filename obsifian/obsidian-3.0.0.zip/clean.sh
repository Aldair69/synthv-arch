#!/bin/sh

rm -f *.exe *.dll
