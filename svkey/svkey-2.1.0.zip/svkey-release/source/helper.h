/*
 * SVPatch: SynthV Patch Helper 2.0
 *
 * Copyright (C) 2023 Xi Jinpwned Software
 *
 * This software is made available to you under the terms of the GNU Affero
 * General Public License version 3.0. For more information, see the included
 * LICENSE.txt file.
 */

#ifndef HELPER_H
#define HELPER_H

#define VERSION "2.1.0"
#define PRODUCT_VERSION 2,1,0,0

#endif
